from setuptools import setup

setup(
    name="paquete",
    version="0.1",
    description="Paquete entrega",
    author="Benjamin Tolosa",
    author_email="benjatolosa2015@gmail.com",
    packages=["paquete"],
)